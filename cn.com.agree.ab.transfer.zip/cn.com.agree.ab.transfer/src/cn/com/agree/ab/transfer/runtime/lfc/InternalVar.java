package cn.com.agree.ab.transfer.runtime.lfc;

import java.util.ArrayList;
import java.util.List;

public class InternalVar {

	private List<String> arg = new ArrayList<String>();

	public List<String> getArg() {
		return arg;
	}

	public void setArg(List<String> arg) {
		this.arg = arg;
	}
	
}
