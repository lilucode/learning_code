package cn.com.agree.ab.transfer.runtime.lfc;
/*
 * exception出口
 */
public class ComponentException {

	private String name = "";
	private String next = "";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNext() {
		return next;
	}

	public void setNext(String next) {
		this.next = next;
	}

}
