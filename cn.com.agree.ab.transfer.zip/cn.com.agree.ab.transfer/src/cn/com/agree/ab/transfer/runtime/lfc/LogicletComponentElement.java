/**
 * Copyright 赞同科技.
 * All rights reserved.
 */
package cn.com.agree.ab.transfer.runtime.lfc;

/**
 * @author PuYun &lt;pu.yun@agree.com.cn&gt; 2014年5月12日 上午11:27:10
 * 
 */
public class LogicletComponentElement extends ComponentElement
{

}
